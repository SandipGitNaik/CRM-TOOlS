
import './App.css';
import Employe from './Component/EmployeComponent/Employe';
import Feedback2 from './Component/FeedbackComponent/Feedback2';
import FeedbackReview from './Component/FeedbackReviewComponent/FeedbackReview';


function App() {
  return (
    <div >
      <header >
      <Feedback2></Feedback2>
      <FeedbackReview/>
      <Employe/>
    </header>
    </div>
  );
}

export default App;
